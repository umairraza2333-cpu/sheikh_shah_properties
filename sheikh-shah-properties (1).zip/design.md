# Sheikh & Shah Properties — Mobile App Design

## Overview

**Sheikh & Shah Properties** is a real estate mobile application designed to streamline the process of buying and selling properties. The app serves as a marketplace where users can browse property listings, view detailed information, and connect with agents to initiate transactions.

---

## Screen List

The mobile app consists of the following primary screens, each optimized for portrait orientation (9:16) and single-handed usage:

| Screen Name | Purpose | Key Content |
|---|---|---|
| **Home** | Entry point; showcases featured properties and quick navigation | Featured listings carousel, search bar, category filters, recent searches |
| **Property Listings** | Browse all properties with filters and sorting | Property cards (image, price, location, bedrooms/bathrooms), filter panel, search results |
| **Property Detail** | In-depth view of a single property | High-res images gallery, full description, amenities, price, location map, agent contact |
| **Buy/Sell Form** | User submission for buying or selling properties | Form fields (property type, location, price, description), image upload, contact info |
| **Agent Contact** | Direct communication with real estate agents | Agent profile, phone/email, inquiry form, message history |
| **Favorites** | Saved properties for later review | Bookmarked property list, quick access to details, remove favorites |
| **Settings** | User preferences and app configuration | Theme toggle (light/dark), notification settings, about, help |

---

## Primary Content and Functionality

### Home Screen
- **Featured Properties Carousel**: Horizontal scrolling carousel displaying 3–4 premium or newly listed properties
- **Search Bar**: Quick search by location, property type, or price range
- **Category Filters**: Buttons for "Buy," "Sell," "Rent," and "New Listings"
- **Recent Searches**: Quick-access list of the user's previous searches
- **Call-to-Action**: Prominent button to "List Your Property" for sellers

### Property Listings
- **Property Cards**: Each card displays a thumbnail image, property name, location, price, and key stats (bedrooms, bathrooms, area in sqft)
- **Filter Panel**: Collapsible panel to refine results by price range, property type, location, and amenities
- **Sorting Options**: Sort by newest, price (low-to-high or high-to-low), or distance
- **Infinite Scroll**: Load more properties as user scrolls down
- **Favorite Button**: Heart icon on each card to save to favorites

### Property Detail
- **Image Gallery**: Full-screen swipeable gallery of property photos
- **Key Information**: Price, address, property type, year built, square footage
- **Description**: Detailed property description and highlights
- **Amenities List**: Icons and text for features (pool, garage, garden, etc.)
- **Location Map**: Embedded map showing property location
- **Agent Card**: Agent name, photo, phone, email with direct contact buttons
- **Inquiry Form**: Quick form to express interest or request a viewing

### Buy/Sell Form
- **Property Type Selector**: Buttons for house, apartment, land, commercial
- **Location Input**: Address field with autocomplete
- **Price Input**: Asking price or budget
- **Description**: Multi-line text field for property details
- **Image Upload**: Camera or gallery picker for property photos (up to 10 images)
- **Contact Information**: Phone and email (pre-filled if logged in)
- **Submit Button**: Send listing to platform

### Agent Contact
- **Agent Profile**: Photo, name, years of experience, rating
- **Contact Methods**: Phone call, WhatsApp, email buttons
- **Inquiry Form**: Pre-filled form to ask questions about properties
- **Message History**: Previous conversations (if applicable)

### Favorites
- **Saved Properties List**: All bookmarked properties in a scrollable list
- **Quick Actions**: View details, remove from favorites, share property
- **Empty State**: Friendly message if no favorites yet

### Settings
- **Theme Toggle**: Switch between light and dark mode
- **Notifications**: Enable/disable push notifications
- **About**: App version, company info, links to privacy policy and terms
- **Help**: FAQ, contact support

---

## Key User Flows

### Flow 1: Browse and Save a Property
1. User opens app → **Home Screen**
2. Taps search bar or browses featured properties
3. Taps a property card → **Property Listings** (filtered results)
4. Taps a property → **Property Detail**
5. Taps heart icon → Property saved to **Favorites**
6. Taps "Contact Agent" → **Agent Contact** screen

### Flow 2: List a Property for Sale
1. User opens app → **Home Screen**
2. Taps "List Your Property" button → **Buy/Sell Form**
3. Fills in property details (type, location, price, description)
4. Uploads property images
5. Enters contact information
6. Taps "Submit" → Confirmation message

### Flow 3: Search with Filters
1. User opens app → **Home Screen**
2. Taps search bar or category filter
3. Applies filters (price range, property type, location) → **Property Listings** (filtered)
4. Sorts results (newest, price)
5. Scrolls through results, taps a property → **Property Detail**

### Flow 4: Contact an Agent
1. User is on **Property Detail**
2. Taps "Contact Agent" → **Agent Contact**
3. Chooses contact method (phone, WhatsApp, email) or fills inquiry form
4. Message sent to agent

---

## Color Choices

The app uses a professional, trust-focused color palette aligned with real estate branding:

| Color | Hex Code | Usage |
|---|---|---|
| **Primary (Teal)** | `#0a7ea4` | Buttons, highlights, active states, links |
| **Background** | `#ffffff` (light) / `#151718` (dark) | Screen background |
| **Surface** | `#f5f5f5` (light) / `#1e2022` (dark) | Cards, panels, elevated surfaces |
| **Foreground (Text)** | `#11181C` (light) / `#ECEDEE` (dark) | Primary text |
| **Muted (Secondary Text)** | `#687076` (light) / `#9BA1A6` (dark) | Secondary text, labels |
| **Border** | `#E5E7EB` (light) / `#334155` (dark) | Dividers, card borders |
| **Success (Green)** | `#22C55E` (light) / `#4ADE80` (dark) | Confirmations, available status |
| **Warning (Amber)** | `#F59E0B` (light) / `#FBBF24` (dark) | Alerts, pending status |
| **Error (Red)** | `#EF4444` (light) / `#F87171` (dark) | Errors, unavailable status |

**Accent Color for Property Cards**: Use a subtle gold (`#D4AF37`) for premium/featured property badges.

---

## Design Principles

1. **Trust & Professionalism**: Clean, minimal design with clear hierarchy
2. **Mobile-First**: All interactions optimized for one-handed use; buttons and touch targets are large (minimum 44×44 pt)
3. **Accessibility**: High contrast ratios, readable fonts, clear labels
4. **Performance**: Fast loading, smooth scrolling, lazy-loaded images
5. **Consistency**: Unified navigation, consistent spacing, predictable interactions

---

## Navigation Structure

```
Home (Tab 1)
├── Search / Featured Properties
├── Property Listings (with filters)
│   └── Property Detail
│       └── Agent Contact
└── Buy/Sell Form

Favorites (Tab 2)
├── Saved Properties List
└── Property Detail
    └── Agent Contact

Settings (Tab 3)
├── Theme & Notifications
├── About
└── Help
```

---

## Next Steps

- Implement core screens with sample data
- Set up navigation structure (tab-based with nested stacks)
- Create reusable components (PropertyCard, FilterPanel, AgentCard)
- Integrate image gallery and map functionality
- Add form validation for Buy/Sell submissions
- Implement favorites persistence (AsyncStorage)
