import { ScrollView, Text, View, TouchableOpacity, TextInput, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";

// Sample featured properties data
const FEATURED_PROPERTIES = [
  {
    id: "1",
    title: "Luxury Villa in Defence",
    price: "PKR 5,000,000",
    location: "Defence, Lahore",
    bedrooms: 4,
    bathrooms: 3,
    image: "🏠",
  },
  {
    id: "2",
    title: "Modern Apartment Downtown",
    price: "PKR 2,500,000",
    location: "Downtown, Karachi",
    bedrooms: 3,
    bathrooms: 2,
    image: "🏢",
  },
  {
    id: "3",
    title: "Spacious House in Gulberg",
    price: "PKR 3,800,000",
    location: "Gulberg, Lahore",
    bedrooms: 5,
    bathrooms: 4,
    image: "🏡",
  },
];

const CATEGORIES = [
  { id: "buy", label: "Buy", icon: "paperplane.fill" },
  { id: "sell", label: "Sell", icon: "arrow.up.arrow.down" },
  { id: "rent", label: "Rent", icon: "home" },
  { id: "new", label: "New", icon: "star.fill" },
];

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();

  const handlePropertyPress = (propertyId: string) => {
    router.push({
      pathname: "/property-detail",
      params: { id: propertyId },
    } as any);
  };

  const handleListProperty = () => {
    router.push({
      pathname: "/buy-sell-form",
    } as any);
  };

  const handleSearch = () => {
    router.push({
      pathname: "/property-listings",
    } as any);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary px-6 pt-6 pb-8">
          <Text className="text-3xl font-bold text-white mb-2">Sheikh & Shah</Text>
          <Text className="text-sm text-white opacity-90">Find Your Perfect Property</Text>
        </View>

        {/* Search Bar */}
        <View className="px-6 -mt-4 mb-6">
          <TouchableOpacity
            onPress={handleSearch}
            className="flex-row items-center bg-white rounded-full px-4 py-3 border border-border shadow-sm"
            style={{ backgroundColor: colors.surface }}
          >
            <IconSymbol name="magnifyingglass" size={20} color={colors.muted} />
            <TextInput
              placeholder="Search by location..."
              placeholderTextColor={colors.muted}
              editable={false}
              className="flex-1 ml-3 text-foreground"
              style={{ color: colors.foreground }}
            />
          </TouchableOpacity>
        </View>

        {/* Category Filters */}
        <View className="px-6 mb-8">
          <FlatList
            data={CATEGORIES}
            keyExtractor={(item) => item.id}
            horizontal
            scrollEnabled={false}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 12 }}
            renderItem={({ item }) => (
              <TouchableOpacity
                className="flex-1 items-center justify-center py-3 px-4 rounded-lg border border-border"
                style={{ backgroundColor: colors.surface }}
              >
                <IconSymbol name={item.icon as any} size={20} color={colors.primary} />
                <Text className="text-xs font-semibold text-foreground mt-1">{item.label}</Text>
              </TouchableOpacity>
            )}
          />
        </View>

        {/* Featured Properties Section */}
        <View className="px-6 mb-8">
          <View className="flex-row items-center justify-between mb-4">
            <Text className="text-xl font-bold text-foreground">Featured Properties</Text>
            <TouchableOpacity onPress={handleSearch}>
              <Text className="text-sm font-semibold text-primary">See All</Text>
            </TouchableOpacity>
          </View>

          <FlatList
            data={FEATURED_PROPERTIES}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            contentContainerStyle={{ gap: 12 }}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() => handlePropertyPress(item.id)}
                className="rounded-2xl overflow-hidden border border-border"
                style={{ backgroundColor: colors.surface }}
              >
                <View className="h-40 items-center justify-center bg-primary opacity-20">
                  <Text className="text-5xl">{item.image}</Text>
                </View>
                <View className="p-4">
                  <Text className="text-lg font-bold text-foreground" numberOfLines={1}>
                    {item.title}
                  </Text>
                  <Text className="text-sm text-muted mt-1">{item.location}</Text>
                  <View className="flex-row gap-4 mt-3 mb-3">
                    <Text className="text-xs text-muted">🛏️ {item.bedrooms} Beds</Text>
                    <Text className="text-xs text-muted">🚿 {item.bathrooms} Baths</Text>
                  </View>
                  <Text className="text-lg font-bold text-primary">{item.price}</Text>
                </View>
              </TouchableOpacity>
            )}
          />
        </View>

        {/* Call-to-Action */}
        <View className="px-6 mb-8">
          <TouchableOpacity
            onPress={handleListProperty}
            className="bg-primary rounded-full py-4 items-center"
          >
            <Text className="text-white font-bold text-base">List Your Property</Text>
          </TouchableOpacity>
        </View>

        {/* Recent Searches */}
        <View className="px-6 pb-8">
          <Text className="text-lg font-bold text-foreground mb-3">Recent Searches</Text>
          <View className="gap-2">
            {["Lahore", "Karachi", "Islamabad"].map((city) => (
              <TouchableOpacity
                key={city}
                className="flex-row items-center py-2 px-3 rounded-lg border border-border"
                style={{ backgroundColor: colors.surface }}
              >
                <IconSymbol name="magnifyingglass" size={16} color={colors.muted} />
                <Text className="text-sm text-foreground ml-2">{city}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
