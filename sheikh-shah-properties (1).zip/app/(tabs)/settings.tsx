import { ScrollView, Text, View, TouchableOpacity, Switch } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useState } from "react";

export default function SettingsScreen() {
  const router = useRouter();
  const colors = useColors();
  const colorScheme = useColorScheme();

  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(colorScheme === "dark");

  const handleToggleDarkMode = () => {
    setDarkMode(!darkMode);
    // In a real app, you would update the theme provider here
  };

  const handleToggleNotifications = () => {
    setNotifications(!notifications);
  };

  const handleAbout = () => {
    alert("Sheikh & Shah Properties v1.0.0\n\nYour trusted real estate marketplace.");
  };

  const handlePrivacy = () => {
    alert("Privacy Policy\n\nYour data is protected and secure.");
  };

  const handleTerms = () => {
    alert("Terms of Service\n\nPlease review our terms and conditions.");
  };

  const handleHelp = () => {
    alert("Help & Support\n\nContact us at support@sheikhshah.com");
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary px-6 py-6">
          <Text className="text-3xl font-bold text-white">Settings</Text>
        </View>

        {/* Preferences Section */}
        <View className="px-6 py-6">
          <Text className="text-lg font-bold text-foreground mb-4">Preferences</Text>

          {/* Dark Mode Toggle */}
          <View
            className="flex-row items-center justify-between p-4 rounded-lg border border-border mb-3"
            style={{ backgroundColor: colors.surface }}
          >
            <View className="flex-row items-center flex-1">
              <IconSymbol name="moon.fill" size={20} color={colors.primary} />
              <View className="ml-4">
                <Text className="text-base font-semibold text-foreground">Dark Mode</Text>
                <Text className="text-xs text-muted mt-1">
                  {darkMode ? "Enabled" : "Disabled"}
                </Text>
              </View>
            </View>
            <Switch
              value={darkMode}
              onValueChange={handleToggleDarkMode}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={darkMode ? colors.primary : colors.muted}
            />
          </View>

          {/* Notifications Toggle */}
          <View
            className="flex-row items-center justify-between p-4 rounded-lg border border-border"
            style={{ backgroundColor: colors.surface }}
          >
            <View className="flex-row items-center flex-1">
              <IconSymbol name="bell.fill" size={20} color={colors.primary} />
              <View className="ml-4">
                <Text className="text-base font-semibold text-foreground">Notifications</Text>
                <Text className="text-xs text-muted mt-1">
                  {notifications ? "Enabled" : "Disabled"}
                </Text>
              </View>
            </View>
            <Switch
              value={notifications}
              onValueChange={handleToggleNotifications}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={notifications ? colors.primary : colors.muted}
            />
          </View>
        </View>

        {/* Information Section */}
        <View className="px-6 py-6">
          <Text className="text-lg font-bold text-foreground mb-4">Information</Text>

          {/* About */}
          <TouchableOpacity
            onPress={handleAbout}
            className="flex-row items-center justify-between p-4 rounded-lg border border-border mb-3"
            style={{ backgroundColor: colors.surface }}
          >
            <View className="flex-row items-center flex-1">
              <IconSymbol name="info.circle.fill" size={20} color={colors.primary} />
              <Text className="text-base font-semibold text-foreground ml-4">About</Text>
            </View>
            <IconSymbol name="chevron.right" size={20} color={colors.muted} />
          </TouchableOpacity>

          {/* Privacy Policy */}
          <TouchableOpacity
            onPress={handlePrivacy}
            className="flex-row items-center justify-between p-4 rounded-lg border border-border mb-3"
            style={{ backgroundColor: colors.surface }}
          >
            <View className="flex-row items-center flex-1">
              <IconSymbol name="checkmark.circle.fill" size={20} color={colors.primary} />
              <Text className="text-base font-semibold text-foreground ml-4">Privacy Policy</Text>
            </View>
            <IconSymbol name="chevron.right" size={20} color={colors.muted} />
          </TouchableOpacity>

          {/* Terms of Service */}
          <TouchableOpacity
            onPress={handleTerms}
            className="flex-row items-center justify-between p-4 rounded-lg border border-border mb-3"
            style={{ backgroundColor: colors.surface }}
          >
            <View className="flex-row items-center flex-1">
              <IconSymbol name="checkmark.circle.fill" size={20} color={colors.primary} />
              <Text className="text-base font-semibold text-foreground ml-4">Terms of Service</Text>
            </View>
            <IconSymbol name="chevron.right" size={20} color={colors.muted} />
          </TouchableOpacity>

          {/* Help & Support */}
          <TouchableOpacity
            onPress={handleHelp}
            className="flex-row items-center justify-between p-4 rounded-lg border border-border"
            style={{ backgroundColor: colors.surface }}
          >
            <View className="flex-row items-center flex-1">
              <IconSymbol name="info.circle.fill" size={20} color={colors.primary} />
              <Text className="text-base font-semibold text-foreground ml-4">Help & Support</Text>
            </View>
            <IconSymbol name="chevron.right" size={20} color={colors.muted} />
          </TouchableOpacity>
        </View>

        {/* App Version */}
        <View className="px-6 py-6 items-center">
          <Text className="text-sm text-muted">Sheikh & Shah Properties</Text>
          <Text className="text-xs text-muted mt-1">Version 1.0.0</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
