import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useState } from "react";

const SAMPLE_FAVORITES = [
  {
    id: "1",
    title: "Luxury Villa in Defence",
    price: "PKR 5,000,000",
    location: "Defence, Lahore",
    bedrooms: 4,
    bathrooms: 3,
    image: "🏠",
  },
  {
    id: "3",
    title: "Spacious House in Gulberg",
    price: "PKR 3,800,000",
    location: "Gulberg, Lahore",
    bedrooms: 5,
    bathrooms: 4,
    image: "🏡",
  },
];

export default function FavoritesScreen() {
  const router = useRouter();
  const colors = useColors();
  const [favorites, setFavorites] = useState(SAMPLE_FAVORITES);

  const handlePropertyPress = (propertyId: string) => {
    router.push({
      pathname: "/property-detail",
      params: { id: propertyId },
    } as any);
  };

  const handleRemoveFavorite = (propertyId: string) => {
    setFavorites((prev) => prev.filter((item) => item.id !== propertyId));
  };

  const handleShare = (property: any) => {
    alert(`Sharing ${property.title}`);
  };

  return (
    <ScreenContainer className="p-0">
      {/* Header */}
      <View className="bg-primary px-6 py-6">
        <Text className="text-3xl font-bold text-white">Favorites</Text>
        <Text className="text-sm text-white opacity-90 mt-1">
          {favorites.length} saved properties
        </Text>
      </View>

      {/* Favorites List */}
      {favorites.length > 0 ? (
        <FlatList
          data={favorites}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16, gap: 12 }}
          scrollEnabled={false}
          renderItem={({ item }) => (
            <View
              className="rounded-2xl overflow-hidden border border-border"
              style={{ backgroundColor: colors.surface }}
            >
              {/* Property Card */}
              <TouchableOpacity onPress={() => handlePropertyPress(item.id)}>
                <View className="h-40 items-center justify-center bg-primary opacity-20">
                  <Text className="text-5xl">{item.image}</Text>
                </View>
                <View className="p-4">
                  <Text className="text-lg font-bold text-foreground" numberOfLines={1}>
                    {item.title}
                  </Text>
                  <Text className="text-sm text-muted mt-1">{item.location}</Text>
                  <View className="flex-row gap-4 mt-3 mb-3">
                    <Text className="text-xs text-muted">🛏️ {item.bedrooms} Beds</Text>
                    <Text className="text-xs text-muted">🚿 {item.bathrooms} Baths</Text>
                  </View>
                  <Text className="text-lg font-bold text-primary">{item.price}</Text>
                </View>
              </TouchableOpacity>

              {/* Action Buttons */}
              <View className="flex-row border-t border-border">
                <TouchableOpacity
                  onPress={() => handlePropertyPress(item.id)}
                  className="flex-1 py-3 items-center border-r border-border"
                  style={{ borderRightColor: colors.border }}
                >
                  <IconSymbol name="eye.fill" size={18} color={colors.primary} />
                  <Text className="text-xs text-primary font-semibold mt-1">View</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => handleShare(item)}
                  className="flex-1 py-3 items-center border-r border-border"
                  style={{ borderRightColor: colors.border }}
                >
                  <IconSymbol name="paperplane.fill" size={18} color={colors.primary} />
                  <Text className="text-xs text-primary font-semibold mt-1">Share</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => handleRemoveFavorite(item.id)}
                  className="flex-1 py-3 items-center"
                >
                  <IconSymbol name="heart.fill" size={18} color={colors.error} />
                  <Text className="text-xs text-error font-semibold mt-1">Remove</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        />
      ) : (
        <View className="flex-1 items-center justify-center px-6">
          <IconSymbol name="heart.fill" size={48} color={colors.muted} />
          <Text className="text-xl font-bold text-foreground mt-4">No Favorites Yet</Text>
          <Text className="text-sm text-muted text-center mt-2">
            Save properties to your favorites to view them later.
          </Text>
        </View>
      )}
    </ScreenContainer>
  );
}
