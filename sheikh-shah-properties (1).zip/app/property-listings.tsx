import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";

const PROPERTIES = [
  {
    id: "1",
    title: "Luxury Villa in Defence",
    price: "PKR 5,000,000",
    location: "Defence, Lahore",
    bedrooms: 4,
    bathrooms: 3,
    image: "🏠",
  },
  {
    id: "2",
    title: "Modern Apartment Downtown",
    price: "PKR 2,500,000",
    location: "Downtown, Karachi",
    bedrooms: 3,
    bathrooms: 2,
    image: "🏢",
  },
  {
    id: "3",
    title: "Spacious House in Gulberg",
    price: "PKR 3,800,000",
    location: "Gulberg, Lahore",
    bedrooms: 5,
    bathrooms: 4,
    image: "🏡",
  },
  {
    id: "4",
    title: "Cozy Apartment in Clifton",
    price: "PKR 4,200,000",
    location: "Clifton, Karachi",
    bedrooms: 2,
    bathrooms: 2,
    image: "🏠",
  },
];

export default function PropertyListingsScreen() {
  const router = useRouter();
  const colors = useColors();

  const handlePropertyPress = (propertyId: string) => {
    router.push({
      pathname: "/property-detail",
      params: { id: propertyId },
    } as any);
  };

  const handleBack = () => {
    router.back();
  };

  return (
    <ScreenContainer className="p-0">
      {/* Header */}
      <View className="bg-primary px-6 py-4 flex-row items-center justify-between">
        <TouchableOpacity onPress={handleBack}>
          <IconSymbol name="chevron.right" size={24} color="white" />
        </TouchableOpacity>
        <Text className="text-xl font-bold text-white">Properties</Text>
        <TouchableOpacity>
          <IconSymbol name="star.fill" size={24} color="white" />
        </TouchableOpacity>
      </View>

      {/* Properties List */}
      <FlatList
        data={PROPERTIES}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 16, gap: 12 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => handlePropertyPress(item.id)}
            className="rounded-2xl overflow-hidden border border-border"
            style={{ backgroundColor: colors.surface }}
          >
            <View className="h-40 items-center justify-center bg-primary opacity-20">
              <Text className="text-5xl">{item.image}</Text>
            </View>
            <View className="p-4">
              <Text className="text-lg font-bold text-foreground" numberOfLines={1}>
                {item.title}
              </Text>
              <Text className="text-sm text-muted mt-1">{item.location}</Text>
              <View className="flex-row gap-4 mt-3 mb-3">
                <Text className="text-xs text-muted">🛏️ {item.bedrooms} Beds</Text>
                <Text className="text-xs text-muted">🚿 {item.bathrooms} Baths</Text>
              </View>
              <Text className="text-lg font-bold text-primary">{item.price}</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </ScreenContainer>
  );
}
