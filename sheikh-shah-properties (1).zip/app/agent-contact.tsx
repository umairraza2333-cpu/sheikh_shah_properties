import { ScrollView, Text, View, TouchableOpacity, TextInput } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useState } from "react";

export default function AgentContactScreen() {
  const router = useRouter();
  const colors = useColors();
  const { agentName, agentPhone } = useLocalSearchParams();

  const [message, setMessage] = useState("");

  const handleBack = () => {
    router.back();
  };

  const handleSendMessage = () => {
    if (!message.trim()) {
      alert("Please enter a message");
      return;
    }

    alert("Message sent to " + agentName + "!");
    setMessage("");
  };

  const handleCall = () => {
    alert("Calling " + agentPhone);
  };

  const handleWhatsApp = () => {
    alert("Opening WhatsApp with " + agentName);
  };

  const handleEmail = () => {
    alert("Opening email client");
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary px-6 py-4 flex-row items-center">
          <TouchableOpacity onPress={handleBack}>
            <IconSymbol name="chevron.right" size={24} color="white" />
          </TouchableOpacity>
          <Text className="text-xl font-bold text-white ml-4">Contact Agent</Text>
        </View>

        {/* Agent Profile */}
        <View className="px-6 py-8 items-center">
          <View className="w-20 h-20 rounded-full bg-primary items-center justify-center mb-4">
            <Text className="text-4xl">👤</Text>
          </View>
          <Text className="text-2xl font-bold text-foreground mb-1">{agentName || "Agent"}</Text>
          <View className="flex-row items-center mt-2">
            <IconSymbol name="star.fill" size={16} color="#FFD700" />
            <Text className="text-sm text-muted ml-2">4.8 (120 reviews)</Text>
          </View>
        </View>

        {/* Contact Methods */}
        <View className="px-6 mb-8">
          <Text className="text-lg font-bold text-foreground mb-4">Quick Contact</Text>

          <View className="gap-3">
            {/* Call Button */}
            <TouchableOpacity
              onPress={handleCall}
              className="flex-row items-center p-4 rounded-lg border border-border"
              style={{ backgroundColor: colors.surface }}
            >
              <View className="w-12 h-12 rounded-full bg-primary items-center justify-center">
                <IconSymbol name="phone.fill" size={20} color="white" />
              </View>
              <View className="flex-1 ml-4">
                <Text className="text-base font-semibold text-foreground">Call Agent</Text>
                <Text className="text-sm text-muted mt-1">{agentPhone}</Text>
              </View>
              <IconSymbol name="chevron.right" size={20} color={colors.muted} />
            </TouchableOpacity>

            {/* WhatsApp Button */}
            <TouchableOpacity
              onPress={handleWhatsApp}
              className="flex-row items-center p-4 rounded-lg border border-border"
              style={{ backgroundColor: colors.surface }}
            >
              <View className="w-12 h-12 rounded-full bg-success items-center justify-center">
                <Text className="text-xl">💬</Text>
              </View>
              <View className="flex-1 ml-4">
                <Text className="text-base font-semibold text-foreground">WhatsApp</Text>
                <Text className="text-sm text-muted mt-1">Send a message</Text>
              </View>
              <IconSymbol name="chevron.right" size={20} color={colors.muted} />
            </TouchableOpacity>

            {/* Email Button */}
            <TouchableOpacity
              onPress={handleEmail}
              className="flex-row items-center p-4 rounded-lg border border-border"
              style={{ backgroundColor: colors.surface }}
            >
              <View className="w-12 h-12 rounded-full bg-primary items-center justify-center">
                <IconSymbol name="envelope.fill" size={20} color="white" />
              </View>
              <View className="flex-1 ml-4">
                <Text className="text-base font-semibold text-foreground">Email</Text>
                <Text className="text-sm text-muted mt-1">Send an email</Text>
              </View>
              <IconSymbol name="chevron.right" size={20} color={colors.muted} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Message Form */}
        <View className="px-6 mb-8">
          <Text className="text-lg font-bold text-foreground mb-4">Send a Message</Text>

          <TextInput
            placeholder="Type your inquiry here..."
            placeholderTextColor={colors.muted}
            value={message}
            onChangeText={setMessage}
            multiline
            numberOfLines={5}
            className="border border-border rounded-lg px-4 py-3 text-foreground"
            style={{
              backgroundColor: colors.surface,
              color: colors.foreground,
              textAlignVertical: "top",
            }}
          />

          <TouchableOpacity
            onPress={handleSendMessage}
            className="bg-primary rounded-full py-4 items-center mt-4 mb-8"
          >
            <Text className="text-white font-bold text-base">Send Message</Text>
          </TouchableOpacity>
        </View>

        {/* Agent Info Card */}
        <View className="px-6 mb-8 p-4 bg-surface rounded-2xl border border-border">
          <Text className="text-base font-semibold text-foreground mb-3">About This Agent</Text>
          <Text className="text-sm text-muted leading-relaxed">
            Experienced real estate professional with over 10 years in the industry. Specializing in
            residential and commercial properties across major cities.
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
