import { ScrollView, Text, View, TouchableOpacity, TextInput } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useState } from "react";

export default function BuySellFormScreen() {
  const router = useRouter();
  const colors = useColors();

  const [formData, setFormData] = useState({
    propertyType: "house",
    location: "",
    price: "",
    description: "",
    phone: "",
    email: "",
  });

  const handleBack = () => {
    router.back();
  };

  const handleSubmit = () => {
    // Validate form
    if (!formData.location || !formData.price || !formData.phone || !formData.email) {
      alert("Please fill in all required fields");
      return;
    }

    alert("Property listing submitted successfully!");
    router.back();
  };

  const updateField = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary px-6 py-4 flex-row items-center">
          <TouchableOpacity onPress={handleBack}>
            <IconSymbol name="chevron.right" size={24} color="white" />
          </TouchableOpacity>
          <Text className="text-xl font-bold text-white ml-4">List Your Property</Text>
        </View>

        {/* Form Content */}
        <View className="px-6 py-6">
          {/* Property Type */}
          <View className="mb-6">
            <Text className="text-base font-semibold text-foreground mb-3">Property Type</Text>
            <View className="flex-row gap-3">
              {["house", "apartment", "land"].map((type) => (
                <TouchableOpacity
                  key={type}
                  onPress={() => updateField("propertyType", type)}
                  className={`flex-1 py-3 px-4 rounded-lg border-2 items-center ${
                    formData.propertyType === type ? "border-primary" : "border-border"
                  }`}
                  style={{
                    backgroundColor:
                      formData.propertyType === type ? colors.primary + "20" : colors.surface,
                  }}
                >
                  <Text
                    className={`text-sm font-semibold capitalize ${
                      formData.propertyType === type ? "text-primary" : "text-foreground"
                    }`}
                  >
                    {type}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Location */}
          <View className="mb-6">
            <Text className="text-base font-semibold text-foreground mb-2">Location *</Text>
            <View className="flex-row items-center border border-border rounded-lg px-4 py-3" style={{ backgroundColor: colors.surface }}>
              <IconSymbol name="map.fill" size={18} color={colors.muted} />
              <TextInput
                placeholder="Enter property location"
                placeholderTextColor={colors.muted}
                value={formData.location}
                onChangeText={(text) => updateField("location", text)}
                className="flex-1 ml-3 text-foreground"
                style={{ color: colors.foreground }}
              />
            </View>
          </View>

          {/* Price */}
          <View className="mb-6">
            <Text className="text-base font-semibold text-foreground mb-2">Price (PKR) *</Text>
            <View className="flex-row items-center border border-border rounded-lg px-4 py-3" style={{ backgroundColor: colors.surface }}>
              <Text className="text-foreground font-semibold">PKR</Text>
              <TextInput
                placeholder="Enter price"
                placeholderTextColor={colors.muted}
                value={formData.price}
                onChangeText={(text) => updateField("price", text)}
                keyboardType="numeric"
                className="flex-1 ml-3 text-foreground"
                style={{ color: colors.foreground }}
              />
            </View>
          </View>

          {/* Description */}
          <View className="mb-6">
            <Text className="text-base font-semibold text-foreground mb-2">Description</Text>
            <TextInput
              placeholder="Describe your property..."
              placeholderTextColor={colors.muted}
              value={formData.description}
              onChangeText={(text) => updateField("description", text)}
              multiline
              numberOfLines={5}
              className="border border-border rounded-lg px-4 py-3 text-foreground"
              style={{
                backgroundColor: colors.surface,
                color: colors.foreground,
                textAlignVertical: "top",
              }}
            />
          </View>

          {/* Image Upload */}
          <View className="mb-6">
            <Text className="text-base font-semibold text-foreground mb-3">Upload Photos</Text>
            <TouchableOpacity
              className="border-2 border-dashed border-primary rounded-lg py-8 items-center justify-center"
              style={{ backgroundColor: colors.primary + "10" }}
            >
              <IconSymbol name="camera.fill" size={32} color={colors.primary} />
              <Text className="text-sm font-semibold text-primary mt-2">Add Photos</Text>
              <Text className="text-xs text-muted mt-1">Up to 10 images</Text>
            </TouchableOpacity>
          </View>

          {/* Contact Information */}
          <View className="mb-6">
            <Text className="text-lg font-bold text-foreground mb-4">Contact Information</Text>

            {/* Phone */}
            <View className="mb-4">
              <Text className="text-base font-semibold text-foreground mb-2">Phone *</Text>
              <View className="flex-row items-center border border-border rounded-lg px-4 py-3" style={{ backgroundColor: colors.surface }}>
                <IconSymbol name="phone.fill" size={18} color={colors.muted} />
                <TextInput
                  placeholder="Your phone number"
                  placeholderTextColor={colors.muted}
                  value={formData.phone}
                  onChangeText={(text) => updateField("phone", text)}
                  keyboardType="phone-pad"
                  className="flex-1 ml-3 text-foreground"
                  style={{ color: colors.foreground }}
                />
              </View>
            </View>

            {/* Email */}
            <View className="mb-6">
              <Text className="text-base font-semibold text-foreground mb-2">Email *</Text>
              <View className="flex-row items-center border border-border rounded-lg px-4 py-3" style={{ backgroundColor: colors.surface }}>
                <IconSymbol name="envelope.fill" size={18} color={colors.muted} />
                <TextInput
                  placeholder="Your email address"
                  placeholderTextColor={colors.muted}
                  value={formData.email}
                  onChangeText={(text) => updateField("email", text)}
                  keyboardType="email-address"
                  className="flex-1 ml-3 text-foreground"
                  style={{ color: colors.foreground }}
                />
              </View>
            </View>
          </View>

          {/* Submit Button */}
          <TouchableOpacity
            onPress={handleSubmit}
            className="bg-primary rounded-full py-4 items-center mb-8"
          >
            <Text className="text-white font-bold text-base">Submit Listing</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
