import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";

const PROPERTY_DATA: Record<string, any> = {
  "1": {
    id: "1",
    title: "Luxury Villa in Defence",
    price: "PKR 5,000,000",
    location: "Defence, Lahore",
    bedrooms: 4,
    bathrooms: 3,
    area: "5,000 sqft",
    year: "2020",
    description:
      "A stunning luxury villa with modern architecture, spacious rooms, and premium amenities. Perfect for families looking for comfort and elegance.",
    amenities: ["Swimming Pool", "Garage", "Garden", "Gym", "Security Gate"],
    agent: {
      name: "Ahmed Khan",
      phone: "+92-300-1234567",
      email: "ahmed@example.com",
    },
  },
  "2": {
    id: "2",
    title: "Modern Apartment Downtown",
    price: "PKR 2,500,000",
    location: "Downtown, Karachi",
    bedrooms: 3,
    bathrooms: 2,
    area: "2,500 sqft",
    year: "2022",
    description:
      "A modern apartment in the heart of downtown with excellent connectivity and nearby amenities. Great for professionals and small families.",
    amenities: ["Parking", "Elevator", "Security", "Balcony"],
    agent: {
      name: "Fatima Ahmed",
      phone: "+92-300-9876543",
      email: "fatima@example.com",
    },
  },
  "3": {
    id: "3",
    title: "Spacious House in Gulberg",
    price: "PKR 3,800,000",
    location: "Gulberg, Lahore",
    bedrooms: 5,
    bathrooms: 4,
    area: "4,500 sqft",
    year: "2019",
    description:
      "A spacious house with beautiful interiors and a large garden. Located in a prime residential area with excellent schools nearby.",
    amenities: ["Large Garden", "Garage", "Servant Quarters", "Lawn"],
    agent: {
      name: "Hassan Ali",
      phone: "+92-300-5555555",
      email: "hassan@example.com",
    },
  },
};

export default function PropertyDetailScreen() {
  const router = useRouter();
  const colors = useColors();
  const { id } = useLocalSearchParams();
  const property = PROPERTY_DATA[id as string] || PROPERTY_DATA["1"];

  const handleBack = () => {
    router.back();
  };

  const handleContactAgent = () => {
    router.push({
      pathname: "/agent-contact",
      params: { agentName: property.agent.name, agentPhone: property.agent.phone },
    } as any);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header with Back Button */}
        <View className="relative">
          <View className="h-48 bg-primary items-center justify-center">
            <Text className="text-6xl">🏠</Text>
          </View>
          <TouchableOpacity
            onPress={handleBack}
            className="absolute top-6 left-6 bg-white rounded-full p-2"
            style={{ backgroundColor: colors.surface }}
          >
            <IconSymbol name="chevron.right" size={20} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity
            className="absolute top-6 right-6 bg-white rounded-full p-2"
            style={{ backgroundColor: colors.surface }}
          >
            <IconSymbol name="heart.fill" size={20} color={colors.error} />
          </TouchableOpacity>
        </View>

        {/* Property Info */}
        <View className="px-6 pt-6">
          <Text className="text-3xl font-bold text-foreground mb-2">{property.title}</Text>
          <View className="flex-row items-center mb-4">
            <IconSymbol name="map.fill" size={16} color={colors.muted} />
            <Text className="text-sm text-muted ml-2">{property.location}</Text>
          </View>

          {/* Price */}
          <Text className="text-2xl font-bold text-primary mb-6">{property.price}</Text>

          {/* Quick Stats */}
          <View className="flex-row gap-4 mb-6">
            <View className="flex-1 bg-surface rounded-lg p-4 items-center">
              <Text className="text-xl font-bold text-foreground">🛏️</Text>
              <Text className="text-xs text-muted mt-1">{property.bedrooms} Bedrooms</Text>
            </View>
            <View className="flex-1 bg-surface rounded-lg p-4 items-center">
              <Text className="text-xl font-bold text-foreground">🚿</Text>
              <Text className="text-xs text-muted mt-1">{property.bathrooms} Bathrooms</Text>
            </View>
            <View className="flex-1 bg-surface rounded-lg p-4 items-center">
              <Text className="text-xl font-bold text-foreground">📐</Text>
              <Text className="text-xs text-muted mt-1">{property.area}</Text>
            </View>
          </View>

          {/* Description */}
          <View className="mb-6">
            <Text className="text-lg font-bold text-foreground mb-2">About</Text>
            <Text className="text-sm text-muted leading-relaxed">{property.description}</Text>
          </View>

          {/* Amenities */}
          <View className="mb-6">
            <Text className="text-lg font-bold text-foreground mb-3">Amenities</Text>
            <FlatList
              data={property.amenities}
              keyExtractor={(item, index) => index.toString()}
              scrollEnabled={false}
              contentContainerStyle={{ gap: 8 }}
              renderItem={({ item }) => (
                <View className="flex-row items-center p-3 bg-surface rounded-lg">
                  <IconSymbol name="checkmark.circle.fill" size={16} color={colors.success} />
                  <Text className="text-sm text-foreground ml-3">{item}</Text>
                </View>
              )}
            />
          </View>

          {/* Agent Info */}
          <View className="mb-6 p-4 bg-surface rounded-2xl border border-border">
            <Text className="text-lg font-bold text-foreground mb-3">Agent Details</Text>
            <Text className="text-base font-semibold text-foreground mb-1">{property.agent.name}</Text>
            <View className="flex-row items-center mb-2">
              <IconSymbol name="phone.fill" size={14} color={colors.primary} />
              <Text className="text-sm text-muted ml-2">{property.agent.phone}</Text>
            </View>
            <View className="flex-row items-center">
              <IconSymbol name="envelope.fill" size={14} color={colors.primary} />
              <Text className="text-sm text-muted ml-2">{property.agent.email}</Text>
            </View>
          </View>

          {/* Contact Agent Button */}
          <TouchableOpacity
            onPress={handleContactAgent}
            className="bg-primary rounded-full py-4 items-center mb-8"
          >
            <Text className="text-white font-bold text-base">Contact Agent</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
